package meetups.headFirstDataPatterns;

public interface Meat {
    public String toString();
}
