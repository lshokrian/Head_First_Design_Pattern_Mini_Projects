package meetups.headFirstDataPatterns;

public interface Veggies {
    public String toString();
}
