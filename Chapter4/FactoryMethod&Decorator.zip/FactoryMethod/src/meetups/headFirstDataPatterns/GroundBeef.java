package meetups.headFirstDataPatterns;

public class GroundBeef implements Meat{
    public String toString(){
        return "Ground Beef";
    }
}
