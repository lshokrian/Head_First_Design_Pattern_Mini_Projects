package meetups.headFirstDataPatterns;

public interface Bread {
    public String toString();
}
