package meetups.headFirstDataPatterns;

public class ShreddedSteak implements Meat {
    public String toString(){
        return "Shredded Steak";
    }
}
