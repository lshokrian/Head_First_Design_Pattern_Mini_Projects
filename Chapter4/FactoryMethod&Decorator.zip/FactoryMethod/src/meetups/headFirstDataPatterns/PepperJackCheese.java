package meetups.headFirstDataPatterns;

public class PepperJackCheese implements Cheese{
    public String toString() {
        return "Pepper Jack Cheese";
    }
}
