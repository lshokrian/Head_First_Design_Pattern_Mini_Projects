package meetups.headFirstDataPatterns;

public class MayoAndKetchup implements Sauce{
    public String toString() {
        return "Mayo and Ketchup";
    }
}
