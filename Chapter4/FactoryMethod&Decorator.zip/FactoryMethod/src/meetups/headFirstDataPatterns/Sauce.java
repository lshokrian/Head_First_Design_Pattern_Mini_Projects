package meetups.headFirstDataPatterns;

public interface Sauce {
    public String toString();
}
