package meetups.headFirstDataPatterns;

public class Pickles implements Veggies {
    public String toString() {
        return "Pickles";
    }
}
