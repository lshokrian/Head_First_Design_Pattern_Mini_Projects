package meetups.headFirstDataPatterns;

//public class CheddarCheese extends CondimentDecorator implements Cheese {
public class CheddarCheese  implements Cheese {
    public String toString() {
        return "Cheddar Cheese";
    }

}
