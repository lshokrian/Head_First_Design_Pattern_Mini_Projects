package meetups.headFirstDataPatterns;

public class Avocado implements Veggies {
    public String toString() {
        return "Avocado";
    }
}
