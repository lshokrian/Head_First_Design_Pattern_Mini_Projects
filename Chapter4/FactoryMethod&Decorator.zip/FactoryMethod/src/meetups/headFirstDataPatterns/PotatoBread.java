package meetups.headFirstDataPatterns;

public class PotatoBread implements Bread {
    public String toString() {
        return "Potato Bread";
    }
}
