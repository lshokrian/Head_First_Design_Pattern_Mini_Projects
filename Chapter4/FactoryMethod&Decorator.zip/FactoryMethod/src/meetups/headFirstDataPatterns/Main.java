package meetups.headFirstDataPatterns;

public class Main {

    public static void main(String[] args) {
        HamburgerStore nyStore = new NewYorkHamburgerStore();
        HamburgerStore utahStore = new UtahHamburgerStore();

        PurchaseItem order1 = ???;
        Hamburger burger1 = nyStore.orderHamburger("beef", order1);
        System.out.println("Person1 ordered " + burger1);
        System.out.println("\n");
        System.out.printf("Person1 ordered - decorator: %s $.2f\n", order1.getDescription(), order1.cost());
/*
        burger1 = utahStore.orderHamburger("beef");
        System.out.println("Person2 ordered " + burger1);

        burger1 = nyStore.orderHamburger("veggie");
        System.out.println("Person3 ordered " + burger1);

        burger1 = utahStore.orderHamburger("veggie");
        System.out.println("Person4 ordered " + burger1);
*/
    }
}
