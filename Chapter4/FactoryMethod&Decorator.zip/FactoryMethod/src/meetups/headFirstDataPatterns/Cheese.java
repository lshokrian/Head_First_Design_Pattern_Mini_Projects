package meetups.headFirstDataPatterns;

public interface Cheese {
    public String toString();
}
