package meetups.headFirstDataPatterns;

public class Lettuce implements Veggies{
    public String toString() {
        return "Lettuce";
    }

}
