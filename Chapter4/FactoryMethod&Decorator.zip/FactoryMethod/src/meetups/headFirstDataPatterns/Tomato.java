package meetups.headFirstDataPatterns;

public class Tomato implements Veggies{
    public String toString() {
        return "Tomato";
    }
}
