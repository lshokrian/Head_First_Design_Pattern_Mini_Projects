package meetups.headFirstDataPatterns;

public class Cilantro implements Veggies{
    public String toString() {
        return "Cilantro";
    }
}
