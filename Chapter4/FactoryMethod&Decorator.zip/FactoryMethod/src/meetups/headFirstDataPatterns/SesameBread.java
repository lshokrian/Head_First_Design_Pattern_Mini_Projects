package meetups.headFirstDataPatterns;

public class SesameBread implements Bread {
    public String toString(){
        return "Sesame Bread";
    }
}
