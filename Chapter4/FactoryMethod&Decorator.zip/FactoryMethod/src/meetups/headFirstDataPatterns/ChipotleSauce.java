package meetups.headFirstDataPatterns;

public class ChipotleSauce implements Sauce {
    public String toString() {
        return "Chipotle Sauce";
    }
}
