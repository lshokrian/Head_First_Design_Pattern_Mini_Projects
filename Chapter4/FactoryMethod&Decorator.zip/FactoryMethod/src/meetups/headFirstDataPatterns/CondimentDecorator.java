package meetups.headFirstDataPatterns;

public abstract class CondimentDecorator extends PurchaseItem{
    public abstract String getDescription();
}
